-----------------------------------------------------------------------------
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE ScopedTypeVariables  #-}
{-# LANGUAGE DerivingStrategies   #-}
{-# LANGUAGE DefaultSignatures    #-}
{-# LANGUAGE OverloadedStrings    #-}
{-# LANGUAGE FlexibleInstances    #-}
{-# LANGUAGE FlexibleContexts     #-}
{-# LANGUAGE KindSignatures       #-}
{-# LANGUAGE TypeOperators        #-}
{-# LANGUAGE LambdaCase           #-}
{-# LANGUAGE DataKinds            #-}
{-# LANGUAGE CPP                  #-}
#if __GLASGOW_HASKELL__ <= 865
{-# LANGUAGE UndecidableInstances #-}
#endif
-----------------------------------------------------------------------------
-- |
-- Module      :  Miso.DSL
-- Copyright   :  (C) 2016-2026 David M. Johnson
-- License     :  BSD3-style (see the file LICENSE)
-- Maintainer  :  David M. Johnson <code@dmj.io>
-- Stability   :  experimental
-- Portability :  non-portable
--
-- = Overview
--
-- "Miso.DSL" is the low-level JavaScript interop layer for miso. It provides
-- the marshaling typeclasses, JS value types, and combinators needed to call
-- browser APIs and exchange data with JavaScript from Haskell.
--
-- Most miso users never import this module directly — higher-level modules
-- ("Miso.FFI", "Miso.Canvas", "Miso.Fetch", etc.) build on top of it.
-- Import it directly when writing custom FFI bindings or inline JS.
--
-- = Marshaling
--
-- Two typeclasses handle the Haskell ↔ JavaScript boundary:
--
-- * 'ToJSVal' — converts a Haskell value into a t'JSVal'. Instances exist
--   for all primitive types, lists, tuples (up to 6), 'Maybe', and
--   'Data.Map.Strict.Map' 'Miso.String.MisoString'. Product record types can
--   derive 'ToJSVal' via @GHC.Generics@ (sum types are not supported).
--
-- * 'FromJSVal' — parses a t'JSVal' back into Haskell, returning
--   @'Maybe' a@ ('Nothing' on type mismatch or missing field).
--   Use 'fromJSValUnchecked' when the shape is guaranteed by the caller.
--   Product record types can derive 'FromJSVal' via @GHC.Generics@.
--
-- Two auxiliary classes support the calling convention:
--
-- * 'ToArgs' — marshals a Haskell value to a @['JSVal']@ argument list.
--   Tuples up to arity 6 automatically produce the correct positional list.
--
-- * 'ToObject' — promotes a value to a JS t'Object' for use as the @this@
--   receiver in method calls.
--
-- = Accessing the global scope
--
-- @
-- -- Read a global variable
-- x <- 'jsg' \"innerWidth\"          -- globalThis.innerWidth
--
-- -- Call a global function
-- 'jsg0' \"requestAnimationFrame\"   -- no args
-- 'jsg1' \"parseInt\" (\"42\" :: 'Miso.String.MisoString')  -- one arg
-- 'jsgf' \"encodeURIComponent\" args -- arbitrary ToArgs
-- @
--
-- = Property access and method calls
--
-- @
-- obj '!' \"name\"          -- get obj.name   :: IO JSVal
-- obj '!!' 3            -- get obj[3]     :: IO JSVal
-- obj '#' \"push\" [val]   -- call obj.push(val) :: IO JSVal
-- 'setField' obj \"x\" 10  -- obj.x = 10
-- 'getProp' \"x\" obj      -- obj.x
-- 'setProp' \"x\" 10 obj   -- obj.x = 10
-- @
--
-- = Object creation
--
-- @
-- o <- 'create'                            -- new empty object  {}
-- o <- 'createWith' [(\"x\", 1), (\"y\", 2)]  -- { x: 1, y: 2 }
-- v <- 'new' constructor args              -- new Constructor(...args)
-- @
--
-- = Callbacks
--
-- Wrap a Haskell @IO@ action as a JS function. Variants ending in @\'@
-- return the t'JSVal' of the callback's return value.
--
-- @
-- cb  <- 'syncCallback'  action         -- () -> ()
-- cb1 <- 'syncCallback1' (\\x -> …)     -- (x) -> ()
-- cb2 <- 'syncCallback2' (\\x y -> …)   -- (x, y) -> ()
-- @
--
-- Always free callbacks when they are no longer needed to avoid leaks:
--
-- @
-- 'freeFunction' cb
-- @
--
-- = See also
--
-- * "Miso.FFI" — higher-level browser API wrappers built on this module
-- * "Miso.FFI.QQ" — the @[js| … |]@ quasi-quoter for inline JavaScript
-- * "Miso.Canvas" — canvas 2D API using 'ToArgs' and 'ToJSVal'
-----------------------------------------------------------------------------
module Miso.DSL
  ( -- * Classes
    ToJSVal (..)
#ifndef __MHS__
  , GToJSVal (..)
#endif
  , FromJSVal (..)
#ifndef __MHS__
  , GFromJSVal (..)
#endif
  , ToArgs (..)
  , ToObject (..)
    -- * Types
  , JSVal
  , Object (..)
  , Function (..)
    -- * Utils
  , jsg
  , jsg0
  , jsg1
  , jsg2
  , jsg3
  , jsg4
  , jsg5
  , jsgf
  , global
  , (#)
  , setField
  , (<##)
  , (!)
  , listProps
  , call
  , new
  , create
  , createWith
  , setProp
  , getProp
  , eval
  , now_ffi
  , requestAnimationFrame
  , cancelAnimationFrame
  , freeFunction
  , freeJSVal
  , (!!)
  , isUndefined
  , isNull
  , jsNull
  , syncCallback
  , syncCallback1
  , syncCallback2
  , syncCallback3
  , syncCallback'
  , syncCallback1'
  , syncCallback2'
  , syncCallback3'
  , await
  , asyncCallback
  , asyncCallback1
  , asyncCallback2
  , asyncCallback3
  , apply
  , JSException
  ) where
-----------------------------------------------------------------------------
import           Control.Applicative
#ifndef VANILLA
import           Data.Text (Text)
#endif
#ifdef __MHS__
import           Control.Monad hiding (forM, forM_, mapM, mapM_, sequence, sequence_)
import           Data.Foldable (forM_, mapM_, sequence_)
import           Data.Traversable (forM, mapM, sequence)
#else
import           Control.Monad
#endif
import           Control.Monad.Trans.Maybe
import qualified Data.Map.Strict as M
import           Data.Map.Strict (Map)
import           GHC.Generics
import           GHC.TypeLits
import           Data.Kind
#ifdef __MHS__
import           Prelude hiding (mapM, mapM_, sequence, sequence_, setField, (!!))
#else
import           Prelude hiding ((!!))
#endif
-----------------------------------------------------------------------------
import           Miso.DSL.FFI
import           Miso.JSON (Value, fromJSVal_Value, toJSVal_Value)
import           Miso.String
-----------------------------------------------------------------------------
-- | A class for marshaling Haskell values into JS
class ToJSVal a where
  toJSVal :: a -> IO JSVal
#ifndef __MHS__
  default toJSVal :: (Generic a, GToJSVal (Rep a)) => a -> IO JSVal
  toJSVal x = do
    o <- create
    gToJSVal (from x) o
    toJSVal o
#endif
-----------------------------------------------------------------------------
#ifndef __MHS__
-- | Internal: writes a t'GHC.Generics.Generic' representation into a JS object
-- field by field. Backs the default 'ToJSVal' implementation; you should not
-- need to write instances.
class GToJSVal (f :: Type -> Type) where
  gToJSVal :: f a -> Object -> IO ()
-----------------------------------------------------------------------------
instance GToJSVal a => GToJSVal (D1 i a) where
  gToJSVal (M1 x) = gToJSVal x
  {-# INLINE gToJSVal #-}
-----------------------------------------------------------------------------
instance GToJSVal a => GToJSVal (C1 i a) where
  gToJSVal (M1 x) = gToJSVal x
  {-# INLINE gToJSVal #-}
-----------------------------------------------------------------------------
instance (GToJSVal a, GToJSVal b) => GToJSVal (a :*: b) where
  gToJSVal (x :*: y) o = gToJSVal x o >> gToJSVal y o
  {-# INLINE gToJSVal #-}
-----------------------------------------------------------------------------
instance (TypeError ('Text "Sum types unsupported"), GToJSVal a, GToJSVal b) => GToJSVal (a :+: b) where
  gToJSVal = \case
    L1 x -> gToJSVal x
    R1 x -> gToJSVal x
  {-# INLINE gToJSVal #-}
-----------------------------------------------------------------------------
instance (ToJSVal a, Selector s) => GToJSVal (S1 s (K1 i a)) where
  gToJSVal (M1 (K1 x)) o =
    setField o fieldName =<< toJSVal x
      where
        fieldName = ms $ selName (undefined :: S1 s (K1 i a) ())
  {-# INLINE gToJSVal #-}
-----------------------------------------------------------------------------
instance GToJSVal U1 where
  gToJSVal U1 _ = pure ()
  {-# INLINE gToJSVal #-}
-----------------------------------------------------------------------------
instance GToJSVal V1 where
  gToJSVal _ _ = pure ()
  {-# INLINE gToJSVal #-}
#endif
-----------------------------------------------------------------------------
instance ToJSVal Bool where
  toJSVal = toJSVal_Bool
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal Double where
  toJSVal = toJSVal_Double
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal Float where
  toJSVal = toJSVal_Float
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal a => ToJSVal (IO a) where
  toJSVal action = toJSVal =<< action
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal () where
  toJSVal () = pure jsNull
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal Char where
  toJSVal = toJSVal_Char
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal Int where
  toJSVal = toJSVal_Int
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal a => ToJSVal (Map MisoString a) where
  toJSVal map_ = do
    o <- create
    forM_ (M.toList map_) $ \(k,v) ->
      setField o k =<< toJSVal v
    toJSVal o
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance FromJSVal a => FromJSVal (Map MisoString a) where
  fromJSVal o = pure <$> do foldM populate M.empty =<< listProps (Object o)
    where
      populate m k = do
        v <- fromJSValUnchecked =<< getProp k (Object o)
        pure (M.insert k v m)
  {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal a => ToObject (Map MisoString a) where
  toObject x = Object <$> toJSVal x
  {-# INLINE toObject #-}
-----------------------------------------------------------------------------
instance ToJSVal a => ToJSVal (Maybe a) where
  toJSVal = \case
    Nothing -> pure jsNull
    Just x -> toJSVal x
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance {-# OVERLAPPABLE #-} FromJSVal a => FromJSVal [a] where
  fromJSVal jsval_ = do
    fromJSVal_List jsval_ >>= \case
      Nothing -> pure Nothing
      Just xs -> sequence <$> mapM fromJSVal xs
  {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
instance FromJSVal [Char] where
  fromJSVal jsval_ = fmap unpack <$> fromJSVal jsval_
  {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal [Char] where
  toJSVal = toJSVal . toMisoString
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance {-# OVERLAPPABLE #-} ToJSVal a => ToJSVal [a] where
  toJSVal = toJSVal_List <=< mapM toJSVal
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal JSVal where
  toJSVal = pure
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance FromJSVal Value where
  fromJSVal = fromJSVal_Value
  {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
-- | A class for marshaling JS values into Haskell
class FromJSVal a where
  fromJSVal :: JSVal -> IO (Maybe a)
#ifndef __MHS__
  default fromJSVal :: (Generic a, GFromJSVal (Rep a)) => JSVal -> IO (Maybe a)
  fromJSVal x = fmap to <$> gFromJSVal (Object x)
#endif
  fromJSValUnchecked :: JSVal -> IO a
  fromJSValUnchecked x = do
    fromJSVal x >>= \case
      Nothing -> error "fromJSValUnchecked: failure"
      Just y -> pure y
-----------------------------------------------------------------------------
#ifndef __MHS__
-- | Internal: rebuilds a t'GHC.Generics.Generic' representation from a JS
-- object, yielding 'Nothing' when a field is missing or ill-typed. Backs the
-- default 'FromJSVal' implementation.
class GFromJSVal (f :: Type -> Type) where
  gFromJSVal :: Object -> IO (Maybe (f a))
-----------------------------------------------------------------------------
instance GFromJSVal a => GFromJSVal (D1 i a) where
  gFromJSVal o = fmap M1 <$> gFromJSVal o
  {-# INLINE gFromJSVal #-}
-----------------------------------------------------------------------------
instance GFromJSVal a => GFromJSVal (C1 i a) where
  gFromJSVal o = fmap M1 <$> gFromJSVal o
  {-# INLINE gFromJSVal #-}
-----------------------------------------------------------------------------
instance GFromJSVal U1 where
  gFromJSVal _ = pure (Just U1)
  {-# INLINE gFromJSVal #-}
-----------------------------------------------------------------------------
instance GFromJSVal V1 where
  gFromJSVal _ = pure Nothing
  {-# INLINE gFromJSVal #-}
-----------------------------------------------------------------------------
instance (GFromJSVal a, GFromJSVal b) => GFromJSVal (a :*: b) where
  gFromJSVal o = runMaybeT $ (:*:) <$> MaybeT (gFromJSVal o) <*> MaybeT (gFromJSVal o)
  {-# INLINE gFromJSVal #-}
-----------------------------------------------------------------------------
instance (TypeError ('Text "Sum types unsupported"), GFromJSVal a, GFromJSVal b) => GFromJSVal (a :+: b) where
  gFromJSVal o = do
    x <- fmap L1 <$> gFromJSVal o
    case x of
      Nothing -> fmap R1 <$> gFromJSVal o
      Just y -> pure (Just y)
  {-# INLINE gFromJSVal #-}
-----------------------------------------------------------------------------
instance (FromJSVal a, Selector s) => GFromJSVal (S1 s (K1 i a)) where
  gFromJSVal o = fmap (M1 . K1) <$> do fromJSVal =<< getProp (ms name) o
    where
      name = selName (undefined :: S1 s (K1 i a) ())
  {-# INLINE gFromJSVal #-}
#endif
-----------------------------------------------------------------------------
instance FromJSVal Int where
  fromJSVal = fromJSVal_Int
  fromJSValUnchecked = fromJSValUnchecked_Int
  {-# INLINE fromJSVal #-}
  {-# INLINE fromJSValUnchecked #-}
-----------------------------------------------------------------------------
instance FromJSVal Char where
  fromJSVal = fromJSVal_Char
  fromJSValUnchecked = fromJSValUnchecked_Char
  {-# INLINE fromJSVal #-}
  {-# INLINE fromJSValUnchecked #-}
-----------------------------------------------------------------------------
instance FromJSVal Float where
  fromJSVal = fromJSVal_Float
  fromJSValUnchecked = fromJSValUnchecked_Float
  {-# INLINE fromJSVal #-}
  {-# INLINE fromJSValUnchecked #-}
-----------------------------------------------------------------------------
instance FromJSVal Double where
  fromJSVal = fromJSVal_Double
  fromJSValUnchecked = fromJSValUnchecked_Double
  {-# INLINE fromJSVal #-}
  {-# INLINE fromJSValUnchecked #-}
-----------------------------------------------------------------------------
instance FromJSVal Text where
  fromJSVal = fromJSVal_Text
  fromJSValUnchecked = fromJSValUnchecked_Text
  {-# INLINE fromJSVal #-}
  {-# INLINE fromJSValUnchecked #-}
-----------------------------------------------------------------------------
instance ToObject Object where
  toObject = pure
  {-# INLINE toObject #-}
-----------------------------------------------------------------------------
instance ToJSVal Value where
  toJSVal = toJSVal_Value
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance ToJSVal Text where
  toJSVal = toJSVal_Text
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance FromJSVal () where
  fromJSVal _ = pure (Just ())
    -- if isUndefined_ffi x || isNull_ffi x
    --   then pure (Just ())
    --   else pure Nothing
  {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
instance (ToJSVal a, ToJSVal b) => ToJSVal (a,b) where
  toJSVal (y,z) = do
    y_ <- toJSVal y
    z_ <- toJSVal z
    toJSVal_List [ y_, z_ ]
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance (ToJSVal a, ToJSVal b, ToJSVal c) => ToJSVal (a,b,c) where
  toJSVal (x,y,z) = do
    x_ <- toJSVal x
    y_ <- toJSVal y
    z_ <- toJSVal z
    toJSVal_List [ x_, y_, z_ ]
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance (ToJSVal a, ToJSVal b, ToJSVal c, ToJSVal d) => ToJSVal (a,b,c,d) where
  toJSVal (w,x,y,z) = do
    w_ <- toJSVal w
    x_ <- toJSVal x
    y_ <- toJSVal y
    z_ <- toJSVal z
    toJSVal_List [ w_, x_, y_, z_ ]
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance (ToJSVal a, ToJSVal b, ToJSVal c, ToJSVal d, ToJSVal e) => ToJSVal (a,b,c,d,e) where
  toJSVal (v,w,x,y,z) = do
    v_ <- toJSVal v
    w_ <- toJSVal w
    x_ <- toJSVal x
    y_ <- toJSVal y
    z_ <- toJSVal z
    toJSVal_List [ v_, w_, x_, y_, z_ ]
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance (ToJSVal a, ToJSVal b, ToJSVal c, ToJSVal d, ToJSVal e, ToJSVal f) => ToJSVal (a,b,c,d,e,f) where
  toJSVal (u,v,w,x,y,z) = do
    u_ <- toJSVal u
    v_ <- toJSVal v
    w_ <- toJSVal w
    x_ <- toJSVal x
    y_ <- toJSVal y
    z_ <- toJSVal z
    toJSVal_List [ u_, v_, w_, x_, y_, z_ ]
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
-- | Retrieves a field from globalThis
jsg :: MisoString -> IO JSVal
jsg key = global ! key
{-# INLINABLE jsg #-}
-----------------------------------------------------------------------------
-- | Invokes a function with a specified argument list
jsgf
  :: ToArgs args
  => MisoString
  -- ^ Global function name on @globalThis@
  -> args
  -- ^ Arguments to pass to the function
  -> IO JSVal
jsgf name = global # name
{-# INLINABLE jsgf #-}
-----------------------------------------------------------------------------
-- | Invokes a function with no argument
jsg0 :: MisoString -> IO JSVal
jsg0 name = jsgf name ([] :: [JSVal])
{-# INLINABLE jsg0 #-}
-----------------------------------------------------------------------------
-- | Invokes a function with 1 argument
jsg1 :: ToJSVal arg => MisoString -> arg -> IO JSVal
jsg1 name arg = jsgf name [arg]
{-# INLINABLE jsg1 #-}
-----------------------------------------------------------------------------
-- | Invokes a function with 2 arguments
jsg2
  :: (ToJSVal arg1, ToJSVal arg2)
  => MisoString
  -- ^ Global function name on @globalThis@
  -> arg1 -- ^ First argument
  -> arg2 -- ^ Second argument
  -> IO JSVal
jsg2 name arg1 arg2 = do
  arg1_ <- toJSVal arg1
  arg2_ <- toJSVal arg2
  jsgf name [arg1_, arg2_]
{-# INLINABLE jsg2 #-}
-----------------------------------------------------------------------------
-- | Invokes a function with 3 arguments
jsg3
  :: (ToJSVal arg1, ToJSVal arg2, ToJSVal arg3)
  => MisoString
  -- ^ Global function name on @globalThis@
  -> arg1 -- ^ First argument
  -> arg2 -- ^ Second argument
  -> arg3 -- ^ Third argument
  -> IO JSVal
jsg3 name arg1 arg2 arg3 = do
  arg1_ <- toJSVal arg1
  arg2_ <- toJSVal arg2
  arg3_ <- toJSVal arg3
  jsgf name [arg1_, arg2_, arg3_]
{-# INLINABLE jsg3 #-}
-----------------------------------------------------------------------------
-- | Invokes a function with 4 arguments
jsg4 :: (ToJSVal arg1, ToJSVal arg2, ToJSVal arg3, ToJSVal arg4)
     => MisoString
     -> arg1
     -> arg2
     -> arg3
     -> arg4
     -> IO JSVal
jsg4 name arg1 arg2 arg3 arg4 = do
  arg1_ <- toJSVal arg1
  arg2_ <- toJSVal arg2
  arg3_ <- toJSVal arg3
  arg4_ <- toJSVal arg4
  jsgf name [arg1_, arg2_, arg3_, arg4_]
{-# INLINABLE jsg4 #-}
-----------------------------------------------------------------------------
-- | Invokes a function with 5 arguments
jsg5 :: (ToJSVal arg1, ToJSVal arg2, ToJSVal arg3, ToJSVal arg4, ToJSVal arg5)
     => MisoString
     -> arg1
     -> arg2
     -> arg3
     -> arg4
     -> arg5
     -> IO JSVal
jsg5 name arg1 arg2 arg3 arg4 arg5 = do
  arg1_ <- toJSVal arg1
  arg2_ <- toJSVal arg2
  arg3_ <- toJSVal arg3
  arg4_ <- toJSVal arg4
  arg5_ <- toJSVal arg5
  jsgf name [arg1_, arg2_, arg3_, arg4_, arg5_]
{-# INLINABLE jsg5 #-}
-----------------------------------------------------------------------------
-- | Sets a field on an Object at a specified field
setField
  :: (ToObject o, ToJSVal v)
  => o
  -- ^ JavaScript object to mutate
  -> MisoString
  -- ^ Field name to set
  -> v
  -- ^ Value to assign
  -> IO ()
setField o k v = do
  o' <- toJSVal =<< toObject o
  v' <- toJSVal v
  setProp_ffi
#ifdef MISO_TEXT
    (textToJSString k)
#else
    k
#endif
    v' o'
{-# INLINABLE setField #-}
-----------------------------------------------------------------------------
-- | Sets a field on an Object at a specified index
infixr 1 <##
(<##) :: (ToObject o, ToJSVal v) => o -> Int -> v -> IO ()
(<##) o k v = do
  o' <- toJSVal =<< toObject o
  v' <- toJSVal v
  setPropIndex_ffi k v' o'
{-# INLINABLE (<##) #-}
-----------------------------------------------------------------------------
-- | Retrieves a property from an Object
(!) :: ToObject o => o -> MisoString -> IO JSVal
(!) = flip getProp
{-# INLINABLE (!) #-}
-----------------------------------------------------------------------------
-- | Lists the properties on a JS Object.
listProps :: Object -> IO [MisoString]
listProps (Object jsval) = do
  keys <- fromJSValUnchecked =<< listProps_ffi jsval
  forM keys fromJSValUnchecked
{-# INLINABLE listProps #-}
-----------------------------------------------------------------------------
-- | Calls a JS function on an t'Object' at a field with specified arguments.
call
  :: (ToObject obj, ToObject this, ToArgs args)
  => obj
  -- ^ The function object to call
  -> this
  -- ^ The @this@ context to bind for the call
  -> args
  -- ^ Arguments to pass to the function
  -> IO JSVal
call o this args = do
  o' <- toJSVal =<< toObject o
  this' <- toJSVal =<< toObject this
  args' <- toJSVal =<< toArgs args
  result <- invokeFunction o' this' args'
  freeJSVal args'
  pure result
{-# INLINABLE call #-}
-----------------------------------------------------------------------------
-- | Calls a JS function on an t'Object' at a field with specified arguments.
infixr 2 #
(#) :: (ToObject object, ToArgs args) => object -> MisoString -> args -> IO JSVal
(#) o k args = do
  o' <- toJSVal =<< toObject o
  func <- getProp_ffi
#ifdef MISO_TEXT
    (textToJSString k)
#else
    k
#endif
    o'
  args' <- toJSVal =<< toArgs args
  result <- invokeFunction func o' args'
  -- @func@ and the argument array are temporaries nobody else can reach;
  -- release them eagerly (see 'freeJSVal'). The argument elements may be the
  -- caller's handles, so only the array itself is freed.
  freeJSVal func
  freeJSVal args'
  pure result
{-# INLINABLE (#) #-}
-----------------------------------------------------------------------------
-- | Calls a JavaScript t'Function' with the given arguments and marshals
-- the result back into Haskell.
--
-- @since 1.13.0.0
apply
  :: (FromJSVal a, ToArgs args)
  => Function
  -- ^ JavaScript function to invoke
  -> args
  -- ^ Arguments to pass to the function
  -> IO a
apply (Function func) args = do
  o <- toJSVal global
  fromJSValUnchecked =<< do
    invokeFunction func o =<<
      toJSVal (toArgs args)
{-# INLINABLE apply #-}
-----------------------------------------------------------------------------
-- | Instantiates a new JS t'Object'.
new
  :: (ToObject constructor, ToArgs args)
  => constructor
  -- ^ JavaScript constructor function (e.g. @jsg \"Array\"@)
  -> args
  -- ^ Constructor arguments
  -> IO JSVal
new constr args = do
  obj <- toJSVal =<< toObject constr
  argv <- toJSVal =<< toArgs args
  result <- new_ffi obj argv
  freeJSVal argv
  pure result
{-# INLINABLE new #-}
-----------------------------------------------------------------------------
-- | Creates a new JS t'Object'
create :: IO Object
create = Object <$> create_ffi
{-# INLINABLE create #-}
-----------------------------------------------------------------------------
-- | Creates a new JS t'Object' populated with key-value pairs specified
-- in the list. Meant for use with 'Miso.FFI.inline' JS functionality.
--
-- @
-- update = \case
--  Highlight domRef -> do
--    3 <- inline "hljs.highlight(domRef); return 3;" =<<
--      createWith [ "domRef" =: domRef ]
--    pure ()
-- @
--
createWith :: ToJSVal val => [(MisoString, val)] -> IO Object
createWith kvs = do
  o <- create
  forM_ kvs $ \(k,v) ->
    flip (setProp k) o =<< toJSVal v
  pure o
{-# INLINABLE createWith #-}
-----------------------------------------------------------------------------
-- | Sets a property on a JS t'Object'
setProp
  :: ToJSVal val
  => MisoString
  -- ^ Property name to set
  -> val
  -- ^ Value to assign
  -> Object
  -- ^ Target JavaScript object
  -> IO ()
setProp k v (Object o) = flip (setProp_ffi
#ifdef MISO_TEXT
    (textToJSString k)
#else
    k
#endif
    ) o =<< toJSVal v
{-# INLINABLE setProp #-}
-----------------------------------------------------------------------------
-- | Retrieves a property from a JS t'Object'
getProp
  :: ToObject o
  => MisoString
  -- ^ Property name to read
  -> o
  -- ^ JavaScript object to read from
  -> IO JSVal
getProp k v = getProp_ffi
#ifdef MISO_TEXT
    (textToJSString k)
#else
    k
#endif
    =<< toJSVal (toObject v)
{-# INLINABLE getProp #-}
-----------------------------------------------------------------------------
-- | Dynamically evaluates a JS string. See [eval](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/eval)
--
-- `eval()` is slower (not subject to JS engine optimizations) and also
-- has security vulnerabilities (can alter other local variables).
--
-- Consider using the more performant and secure (isolated) `inline` function.
--
eval :: MisoString -> IO JSVal
eval =
#ifdef MISO_TEXT
  eval_ffi . textToJSString
#else
  eval_ffi
#endif
{-# INLINABLE eval #-}
-----------------------------------------------------------------------------
instance FromJSVal Bool where
  fromJSVal = fromJSVal_Bool
  fromJSValUnchecked = fromJSValUnchecked_Bool
  {-# INLINE fromJSVal #-}
  {-# INLINE fromJSValUnchecked #-}
-----------------------------------------------------------------------------
instance FromJSVal JSVal where
  fromJSVal = pure . Just
  {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
instance FromJSVal a => FromJSVal (Maybe a) where
  fromJSVal x = fromJSVal_Maybe x >>= \case
    Nothing -> pure Nothing
    Just Nothing -> pure (Just Nothing)
    Just (Just y) -> fmap Just <$> fromJSVal y
  fromJSValUnchecked x = fromJSValUnchecked_Maybe x >>= \case
    Nothing -> pure Nothing
    Just y -> Just <$> fromJSValUnchecked y
  {-# INLINE fromJSVal #-}
  {-# INLINE fromJSValUnchecked #-}
-----------------------------------------------------------------------------
-- | A class for creating arguments to a JS function
class ToArgs args where
  toArgs :: args -> IO [JSVal]
-----------------------------------------------------------------------------
instance ToArgs Double where
  toArgs x = (:[]) <$> toJSVal x
  {-# INLINE toArgs #-}
-----------------------------------------------------------------------------
instance ToArgs JSVal where
  toArgs val = pure [val]
  {-# INLINE toArgs #-}
-----------------------------------------------------------------------------
instance ToObject JSVal where
  toObject = pure . Object
  {-# INLINE toObject #-}
-----------------------------------------------------------------------------
-- | A class for creating JS objects.
class ToObject a where
  toObject :: a -> IO Object
#ifndef __MHS__
  default toObject :: (Generic a, GToJSVal (Rep a)) => a -> IO Object
  toObject x = do
    o <- create
    gToJSVal (from x) o
    pure o
#endif
-----------------------------------------------------------------------------
instance ToJSVal a => ToObject (IO a) where
  toObject action = Object <$> (toJSVal =<< action)
  {-# INLINE toObject #-}
-----------------------------------------------------------------------------
instance ToArgs MisoString where
  toArgs arg = (:[]) <$> toJSVal arg
  {-# INLINE toArgs #-}
----------------------------------------------------------------------------
#if !defined(VANILLA) && !defined(MISO_TEXT)
----------------------------------------------------------------------------
instance ToJSVal MisoString where
  toJSVal = toJSVal_JSString
  {-# INLINE toJSVal #-}
-----------------------------------------------------------------------------
instance FromJSVal MisoString where
  fromJSVal = fromJSVal_JSString
  {-# INLINE fromJSVal #-}
----------------------------------------------------------------------------
#endif
----------------------------------------------------------------------------
instance ToJSVal arg => ToArgs [arg] where
    toArgs = mapM toJSVal
    {-# INLINE toArgs #-}
----------------------------------------------------------------------------
instance ToArgs () where
  toArgs _ = pure []
  {-# INLINE toArgs #-}
----------------------------------------------------------------------------
instance ToArgs Int where
  toArgs k = (:[]) <$> toJSVal k
  {-# INLINE toArgs #-}
-----------------------------------------------------------------------------
instance ToArgs Function where
  toArgs k = (:[]) <$> toJSVal k
  {-# INLINE toArgs #-}
-----------------------------------------------------------------------------
instance ToArgs Bool where
  toArgs k = (:[]) <$> toJSVal k
  {-# INLINE toArgs #-}
-----------------------------------------------------------------------------
instance ToArgs Object where
  toArgs k = (:[]) <$> toJSVal k
  {-# INLINE toArgs #-}
-----------------------------------------------------------------------------
instance ToArgs args => ToArgs (Maybe args) where
  toArgs (Just args) = toArgs args
  toArgs Nothing     = pure []
  {-# INLINE toArgs #-}
----------------------------------------------------------------------------
instance (ToJSVal arg1, ToJSVal arg2) => ToArgs (arg1, arg2) where
  toArgs (arg1, arg2) = do
    rarg1 <- toJSVal arg1
    rarg2 <- toJSVal arg2
    return [rarg1, rarg2]
  {-# INLINE toArgs #-}
----------------------------------------------------------------------------
instance (ToJSVal arg1, ToJSVal arg2, ToJSVal arg3) => ToArgs (arg1, arg2, arg3) where
  toArgs (arg1, arg2, arg3) = do
    rarg1 <- toJSVal arg1
    rarg2 <- toJSVal arg2
    rarg3 <- toJSVal arg3
    return [rarg1, rarg2, rarg3]
  {-# INLINE toArgs #-}
----------------------------------------------------------------------------
instance (ToJSVal arg1, ToJSVal arg2, ToJSVal arg3, ToJSVal arg4) => ToArgs (arg1, arg2, arg3, arg4) where
  toArgs (arg1, arg2, arg3, arg4) = do
    rarg1 <- toJSVal arg1
    rarg2 <- toJSVal arg2
    rarg3 <- toJSVal arg3
    rarg4 <- toJSVal arg4
    return [rarg1, rarg2, rarg3, rarg4]
  {-# INLINE toArgs #-}
----------------------------------------------------------------------------
instance (ToJSVal arg1, ToJSVal arg2, ToJSVal arg3, ToJSVal arg4, ToJSVal arg5) => ToArgs (arg1, arg2, arg3, arg4, arg5) where
  toArgs (arg1, arg2, arg3, arg4, arg5) = do
    rarg1 <- toJSVal arg1
    rarg2 <- toJSVal arg2
    rarg3 <- toJSVal arg3
    rarg4 <- toJSVal arg4
    rarg5 <- toJSVal arg5
    return [rarg1, rarg2, rarg3, rarg4, rarg5]
  {-# INLINE toArgs #-}
----------------------------------------------------------------------------
instance (ToJSVal arg1, ToJSVal arg2, ToJSVal arg3, ToJSVal arg4, ToJSVal arg5, ToJSVal arg6) => ToArgs (arg1, arg2, arg3, arg4, arg5, arg6) where
  toArgs (arg1, arg2, arg3, arg4, arg5, arg6) = do
    rarg1 <- toJSVal arg1
    rarg2 <- toJSVal arg2
    rarg3 <- toJSVal arg3
    rarg4 <- toJSVal arg4
    rarg5 <- toJSVal arg5
    rarg6 <- toJSVal arg6
    return [rarg1, rarg2, rarg3, rarg4, rarg5, rarg6]
  {-# INLINE toArgs #-}
----------------------------------------------------------------------------
-- | Frees references to a callback
freeFunction :: Function -> IO ()
freeFunction (Function x) = freeFunction_ffi x
{-# INLINABLE freeFunction #-}
-----------------------------------------------------------------------------
-- | Eagerly release a 'JSVal' handle.
--
-- On the WASM backend every 'JSVal' carries a weak pointer and a C finalizer
-- so that the JavaScript value can be released once the handle is garbage
-- collected. The RTS must evacuate every such weak pointer on every GC (dead
-- or alive) before it can run the finalizer, so short-lived handles created
-- in bulk (e.g. while building a virtual DOM) make each GC pause scale with
-- the number of handles allocated since the last one. 'freeJSVal' unlinks
-- the weak pointer and releases the JavaScript side immediately, so the
-- handle costs the GC nothing.
--
-- Only the Haskell handle is released: the JavaScript value itself stays
-- alive for as long as something on the JavaScript side references it.
--
-- Using a 'JSVal' after it has been freed is undefined behaviour, so only
-- free handles that no other Haskell code (including callbacks that close
-- over them) can reach. Note that on WASM a 'JSString' /is/ a 'JSVal', so
-- never free a handle obtained from 'toJSVal' on a string you do not own.
--
-- No-op on the GHCJS and native backends.
freeJSVal :: JSVal -> IO ()
freeJSVal = freeJSVal_ffi
{-# INLINABLE freeJSVal #-}
-----------------------------------------------------------------------------
instance FromJSVal Function where
  fromJSVal x = do
    missing <- (||) <$> isUndefined x <*> isNull x
    pure $ if missing then Nothing else Just (Function x)
  {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
instance FromJSVal Object where
  fromJSVal x = do
    missing <- (||) <$> isUndefined x <*> isNull x
    pure $ if missing then Nothing else Just (Object x)
  {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
-- | Lookup a property based on its index
(!!) :: ToObject object => object -> Int -> IO JSVal
(!!) o k = getPropIndex_ffi k =<< toJSVal =<< toObject o
{-# INLINABLE (!!) #-}
-----------------------------------------------------------------------------
-- | Checks if a t'JSVal' is undefined
isUndefined :: ToJSVal val => val -> IO Bool
isUndefined val = isUndefined_ffi <$> toJSVal val
{-# INLINABLE isUndefined #-}
-----------------------------------------------------------------------------
-- | Checks if a t'JSVal' is null
isNull :: ToJSVal val => val -> IO Bool
isNull val = isNull_ffi <$> toJSVal val
{-# INLINABLE isNull #-}
-----------------------------------------------------------------------------
-- | A JS Object
newtype Object = Object { unObject :: JSVal } deriving newtype (ToJSVal, Eq)
-----------------------------------------------------------------------------
-- | A JS Functionn
newtype Function = Function { unFunction :: JSVal } deriving newtype (ToJSVal, Eq)
-----------------------------------------------------------------------------
instance (FromJSVal a, FromJSVal b) => FromJSVal (a,b) where
    fromJSVal r = runMaybeT $ (,) <$> jf r 0 <*> jf r 1
    {-# INLINE fromJSVal #-}
instance (FromJSVal a, FromJSVal b, FromJSVal c) => FromJSVal (a,b,c) where
    fromJSVal r = runMaybeT $ (,,) <$> jf r 0 <*> jf r 1 <*> jf r 2
    {-# INLINE fromJSVal #-}
instance (FromJSVal a, FromJSVal b, FromJSVal c, FromJSVal d) => FromJSVal (a,b,c,d) where
    fromJSVal r = runMaybeT $ (,,,) <$> jf r 0 <*> jf r 1 <*> jf r 2 <*> jf r 3
    {-# INLINE fromJSVal #-}
instance (FromJSVal a, FromJSVal b, FromJSVal c, FromJSVal d, FromJSVal e) => FromJSVal (a,b,c,d,e) where
    fromJSVal r = runMaybeT $ (,,,,) <$> jf r 0 <*> jf r 1 <*> jf r 2 <*> jf r 3 <*> jf r 4
    {-# INLINE fromJSVal #-}
instance (FromJSVal a, FromJSVal b, FromJSVal c, FromJSVal d, FromJSVal e, FromJSVal f) => FromJSVal (a,b,c,d,e,f) where
    fromJSVal r = runMaybeT $ (,,,,,) <$> jf r 0 <*> jf r 1 <*> jf r 2 <*> jf r 3 <*> jf r 4 <*> jf r 5
    {-# INLINE fromJSVal #-}
instance (FromJSVal a, FromJSVal b, FromJSVal c, FromJSVal d, FromJSVal e, FromJSVal f, FromJSVal g) => FromJSVal (a,b,c,d,e,f,g) where
    fromJSVal r = runMaybeT $ (,,,,,,) <$> jf r 0 <*> jf r 1 <*> jf r 2 <*> jf r 3 <*> jf r 4 <*> jf r 5 <*> jf r 6
    {-# INLINE fromJSVal #-}
instance (FromJSVal a, FromJSVal b, FromJSVal c, FromJSVal d, FromJSVal e, FromJSVal f, FromJSVal g, FromJSVal h) => FromJSVal (a,b,c,d,e,f,g,h) where
    fromJSVal r = runMaybeT $ (,,,,,,,) <$> jf r 0 <*> jf r 1 <*> jf r 2 <*> jf r 3 <*> jf r 4 <*> jf r 5 <*> jf r 6 <*> jf r 7
    {-# INLINE fromJSVal #-}
-----------------------------------------------------------------------------
jf :: FromJSVal a => JSVal -> Int -> MaybeT IO a
{-# INLINE jf #-}
jf r n = MaybeT $ do
  x <- getPropIndex_ffi n r
  if isUndefined_ffi r
    then return Nothing
    else fromJSVal x
-----------------------------------------------------------------------------
