-----------------------------------------------------------------------------
{-# LANGUAGE OverloadedStrings #-}
-----------------------------------------------------------------------------
-- |
-- Module      :  Miso.Mathml.Element
-- Copyright   :  (C) 2016-2026 David M. Johnson
-- License     :  BSD3-style (see the file LICENSE)
-- Maintainer  :  David M. Johnson <code@dmj.io>
-- Stability   :  experimental
-- Portability :  non-portable
--
-- = Overview
--
-- "Miso.Mathml.Element" provides smart constructors for every element in the
-- <https://developer.mozilla.org/en-US/docs/Web/MathML MathML Core>
-- vocabulary. Each constructor produces a 'Miso.Types.View' node in the
-- @MATHML@ namespace:
--
-- @
-- tagName_ :: ['Miso.Types.Attribute' action] -> ['Miso.Types.View' model action] -> 'Miso.Types.View' model action
-- @
--
-- All names are suffixed with @_@. The module is re-exported by "Miso.Mathml".
--
-- = Quick start
--
-- Embed a fraction inside a paragraph using 'Miso.Html.Element.p_' and 'math_':
--
-- @
-- import "Miso"
-- import "Miso.Mathml.Element"
-- import "Miso.Mathml.Property" (@display_@)
--
-- formula :: 'Miso.Types.View' model action
-- formula =
--   'Miso.Html.Element.p_' []
--     [ 'math_' [ @display_@ \"block\" ]
--         [ 'mfrac_' []
--             [ 'mn_' [] [ 'Miso.text' \"1\" ]
--             , 'msqrt_' [] [ 'mn_' [] [ 'Miso.text' \"2\" ] ]
--             ]
--         ]
--     ]
-- @
--
-- = Element groups
--
-- * __Top-level__: 'math_'
-- * __Token elements__ (leaves): 'mi_' (identifier), 'mn_' (number),
--   'mo_' (operator), 'ms_' (string literal), 'mtext_', 'mspace_'
-- * __General layout__: 'mrow_', 'mfrac_', 'msqrt_', 'mroot_',
--   'mpadded_', 'mphantom_', 'merror_', 'mstyle_', 'mfenced_'
-- * __Script \& limit__: 'msub_', 'msup_', 'msubsup_',
--   'mover_', 'munder_', 'munderover_', 'mmultiscripts_', 'mprescripts_'
-- * __Tabular__: 'mtable_', 'mtr_', 'mtd_'
-- * __Semantics__: 'semantics_', 'annotation_', 'annotationXml_'
-- * __Custom__: 'nodeMathml' for any MathML tag not listed above
--
-- = See also
--
-- * "Miso.Mathml.Property" — MathML attribute combinators
-- * "Miso.Mathml" — re-export hub for the full MathML DSL
-- * "Miso.Html.Element" — HTML element constructors
-- * "Miso.Svg.Element" — SVG element constructors
-----------------------------------------------------------------------------
module Miso.Mathml.Element
  ( -- ** Combinator
    nodeMathml
   -- ** Elements
  , math_
  , annotationXml_
  , annotation_
  , merror_
  , mfrac_
  , mi_
  , mmultiscripts_
  , mn_
  , mo_
  , mover_
  , mpadded_
  , mphantom_
  , mprescripts_
  , mroot_
  , mrow_
  , ms_
  , mspace_
  , msqrt_
  , mstyle_
  , msub_
  , msubsup_
  , msup_
  , mtable_
  , mtd_
  , mtext_
  , mtr_
  , munder_
  , munderover_
  , semantics_
  , mfenced_
  ) where
-----------------------------------------------------------------------------
import           Miso.Types
-----------------------------------------------------------------------------
-- | Low-level helper used to construct 'MATHML' 'node' in 'Miso.Types.View'.
-- Most View helpers in this module are defined in terms of it.
nodeMathml :: MisoString -> [Attribute model action] -> [View context props model action] -> View context props model action
nodeMathml nodeName = node MATHML nodeName
-----------------------------------------------------------------------------
-- | [\<annotation-xml\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/annotation-xml)
--
-- @since 1.9.0.0
annotationXml_ :: [Attribute model action] -> [View context props model action] -> View context props model action
annotationXml_ = nodeMathml "annotation-xml"
-----------------------------------------------------------------------------
-- | [\<annotation\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/annotation)
--
-- @since 1.9.0.0
annotation_ :: [Attribute model action] -> [View context props model action] -> View context props model action
annotation_ = nodeMathml "annotation"
-----------------------------------------------------------------------------
-- | [\<math\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/math)
--
-- @since 1.9.0.0
math_ :: [Attribute model action] -> [View context props model action] -> View context props model action
math_ = nodeMathml "math"
-----------------------------------------------------------------------------
-- | [\<merror\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/merror)
--
-- @since 1.9.0.0
merror_ :: [Attribute model action] -> [View context props model action] -> View context props model action
merror_ = nodeMathml "merror"
-----------------------------------------------------------------------------
-- | [\<mfrac\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mfrac)
--
-- @since 1.9.0.0
mfrac_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mfrac_ = nodeMathml "mfrac"
-----------------------------------------------------------------------------
-- | [\<mi\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mi)
--
-- @since 1.9.0.0
mi_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mi_ = nodeMathml "mi"
-----------------------------------------------------------------------------
-- | [\<mmultiscripts\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mmultiscripts)
--
-- @since 1.9.0.0
mmultiscripts_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mmultiscripts_ = nodeMathml "mmultiscripts"
-----------------------------------------------------------------------------
-- | [\<mn\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mn)
--
-- @since 1.9.0.0
mn_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mn_ = nodeMathml "mn"
-----------------------------------------------------------------------------
-- | [\<mo\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mo)
--
-- @since 1.9.0.0
mo_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mo_ = nodeMathml "mo"
-----------------------------------------------------------------------------
-- | [\<mover\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mover)
--
-- @since 1.9.0.0
mover_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mover_ = nodeMathml "mover"
-----------------------------------------------------------------------------
-- | [\<mpadded\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mpadded)
--
-- @since 1.9.0.0
mpadded_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mpadded_ = nodeMathml "mpadded"
-----------------------------------------------------------------------------
-- | [\<mphantom\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mphantom)
--
-- @since 1.9.0.0
mphantom_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mphantom_ = nodeMathml "mphantom"
-----------------------------------------------------------------------------
-- | [\<mprescripts\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mprescripts)
--
-- @since 1.9.0.0
mprescripts_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mprescripts_ = nodeMathml "mprescripts"
-----------------------------------------------------------------------------
-- | [\<mroot\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mroot)
--
-- @since 1.9.0.0
mroot_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mroot_ = nodeMathml "mroot"
-----------------------------------------------------------------------------
-- | [\<mrow\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mrow)
--
-- @since 1.9.0.0
mrow_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mrow_ = nodeMathml "mrow"
-----------------------------------------------------------------------------
-- | [\<ms\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/ms)
--
-- @since 1.9.0.0
ms_ :: [Attribute model action] -> [View context props model action] -> View context props model action
ms_ = nodeMathml "ms"
-----------------------------------------------------------------------------
-- | [\<mspace\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mspace)
--
-- @since 1.9.0.0
mspace_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mspace_ = nodeMathml "mspace"
-----------------------------------------------------------------------------
-- | [\<msqrt\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/msqrt)
--
-- @since 1.9.0.0
msqrt_ :: [Attribute model action] -> [View context props model action] -> View context props model action
msqrt_ = nodeMathml "msqrt"
-----------------------------------------------------------------------------
-- | [\<mstyle\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mstyle)
--
-- @since 1.9.0.0
mstyle_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mstyle_ = nodeMathml "mstyle"
-----------------------------------------------------------------------------
-- | [\<msub\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/msub)
--
-- @since 1.9.0.0
msub_ :: [Attribute model action] -> [View context props model action] -> View context props model action
msub_ = nodeMathml "msub"
-----------------------------------------------------------------------------
-- | [\<msubsup\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/msubsup)
--
-- @since 1.9.0.0
msubsup_ :: [Attribute model action] -> [View context props model action] -> View context props model action
msubsup_ = nodeMathml "msubsup"
-----------------------------------------------------------------------------
-- | [\<msup\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/msup)
--
-- @since 1.9.0.0
msup_ :: [Attribute model action] -> [View context props model action] -> View context props model action
msup_ = nodeMathml "msup"
-----------------------------------------------------------------------------
-- | [\<mtable\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mtable)
--
-- @since 1.9.0.0
mtable_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mtable_ = nodeMathml "mtable"
-----------------------------------------------------------------------------
-- | [\<mtd\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mtd)
--
-- @since 1.9.0.0
mtd_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mtd_ = nodeMathml "mtd"
-----------------------------------------------------------------------------
-- | [\<mtext\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mtext)
--
-- @since 1.9.0.0
mtext_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mtext_ = nodeMathml "mtext"
-----------------------------------------------------------------------------
-- | [\<mtr\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mtr)
--
-- @since 1.9.0.0
mtr_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mtr_ = nodeMathml "mtr"
-----------------------------------------------------------------------------
-- | [\<munder\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/munder)
--
-- @since 1.9.0.0
munder_ :: [Attribute model action] -> [View context props model action] -> View context props model action
munder_ = nodeMathml "munder"
-----------------------------------------------------------------------------
-- | [\<munderover\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/munderover)
--
-- @since 1.9.0.0
munderover_ :: [Attribute model action] -> [View context props model action] -> View context props model action
munderover_ = nodeMathml "munderover"
-----------------------------------------------------------------------------
-- | [\<semantics\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/semantics)
--
-- @since 1.9.0.0
semantics_ :: [Attribute model action] -> [View context props model action] -> View context props model action
semantics_ = nodeMathml "semantics"
-----------------------------------------------------------------------------
-- | [\<semantics\>](https://developer.mozilla.org/en-US/docs/Web/MathML/Reference/Element/mfenced)
--
-- @since 1.9.0.0
mfenced_ :: [Attribute model action] -> [View context props model action] -> View context props model action
mfenced_ = nodeMathml "mfenced"
-----------------------------------------------------------------------------
